import requests
import json
from langchain_ibm import ChatWatsonx
import json, re
import ast
from pydantic import BaseModel, Field

llm = ChatWatsonx( 
        model_id="mistralai/mistral-medium-2505",
        params={
             "decoding_method": "greedy",
             "max_new_tokens": 500,
             "max_tokens": 5000,             
             "min_new_tokens": 0,
             "temperature": 0,
             'stop_sequences': [],
        },
        project_id="fffff424-954f-4d89-883b-d48bcf921d0d",
        url="https://us-south.ml.cloud.ibm.com/",
        apikey="3gzJyVBlsom4znh1OJRbRFrr_J9QaeE7Su3fV6_ALHwN"
    )

# # Instructions:
#     - Determine test case ID from user query.
#     - Determine data source name from user query.
#     - Evaluate if data source name found can really be a source of data. Set "data_source" and "has_data_source" accordingly, post evaluation.


TEST_CASE_SYSTEM = "You are an intelligent data extractor assistant."

TEST_CASE_USER = f'''
Your task is to extract test case id and data source name from user query, if present.

# Rule to identify Test case id:
   A test case ID follows this format: XXX-XXX-00000, where:
   - X is an uppercase letter
   - 0 is a digit
   If test case ID found then set "test_case_id" with value and set "has_test_case" to True

# Rule to identify data source name:
   - A data source name can be noun, proper name or title in user query that refers to dataset, report, document, repository, etc., from which data is to be taken. 
   - A data source can used with prepositions like "in", "from", "by", "at", "under" etc.
   - A data source can also be followed by keywords like "refer", "check in", "look in", "mentioned in", "search in", so on.   
   - A data source name may also end with file extensions like pdf, xlsx, etc.
   - Extract exactly as mentioned in the query, preserving case and spaces.
   - If data source name found then set "data_source" with value and set "has_data_source" to True

# Examples:
   Q: "what is the category for the test case id DSH-DCT-00042."
   A: {{"has_test_case": True, "test_case_id": "DSH-DCT-00042", "has_data_source": False, "data_source": "" }}

   Q: "Count all the test cases in CallBox DPT."
   A: {{"has_test_case": False, "test_case_id": "", "has_data_source": True, "data_source": "CallBox DPT" }}

   Q: "List all the categories from Boost Callbox DPT (Wearables) Test Plan v25.Q1.2.xlsx"
   A: {{"has_test_case": False, "test_case_id": "", "has_data_source": True, "data_source": "Boost DCT Lab (Tablet) Test Plan v25.Q1.1.xlsx" }}

   Q: "How many weeks for MR testing?"
   A: {{"has_test_case": False, "test_case_id": "", "has_data_source": False, "data_source": "" }}

'''

class ExtractionResult(BaseModel):
    query: str = Field(..., description="user query")     
    has_test_case: bool = Field(..., description="True if a test case id is found in the query, else false")
    test_case_id: str = Field(..., description="The exact test case id found, or empty string if none")    
    has_data_source: bool = Field(..., description="True if a filename is found in the query, else false")
    data_source: str = Field(..., description="The exact filename found, or empty string if none")




# check for test case id & data source name
def is_test_case_present(user_query):
    system = TEST_CASE_SYSTEM

    user = f""" {TEST_CASE_USER}
    Input:
        {user_query}

    Response:

    """

    # Final mistral-style prompt
    mistral_prompt = f"""
    <|system|>
    {system}
    
    <|user|>
    {user}
    
    ai_response:
    <|assistant|>
    """

    structured_llm = llm.with_structured_output(ExtractionResult) 
    result = structured_llm.invoke(mistral_prompt)
    print(result)
    return result


query = [ 
        # "What SKUs are in DISH? refer Wireless All Brand M2M",
        # "What are the GID values in DISH Wireless All Brand M2M & Consumer eSIM Profile",
        # "list down the 5G-SA CA band combinations from Boost Mobile 5G-SA CA Combinations",
        # "list down the 5G-SA CA band combinations",
        # "display the 5G-SA CA band combinations. search in Boost Mobile 5G-SA CA",
        # "List down the CA band combination for boost network",
        # "What is the algorithm used for OMA-DM client generation password?",
        # "What SKUs are in DISH Wireless All Brand M2M & Consumer eSIM Profile Spec",
        # "give me DL combo",
        # "Explain the algorithm used to generate the client password in an OMA-DM client?",
        # "category for test case id DSH-DCT-00036",
        # "What is the process for device certification?",
        # "What SKUs are covered by DISH Wireless All Brand M2M & Consumer eSIM Profile Spec", 
        # "What 3GPP spec can I find the EF files for a SIM in?",
        # "What are the GID values of Enterprise?",      
        # "what is the test procedure for DFIT handset test case DSH-DCT-00042" ,
        "5G-SA CA band combinations from Boost Mobile 5G-SA CA Combinations"
        
        ]

for item in query:
    is_test_case_present(item)
