from langchain_ibm import ChatWatsonx

WATSONX_PROJECT_ID="fffff424-954f-4d89-883b-d48bcf921d0d"
WATSONX_API_KEY="3gzJyVBlsom4znh1OJRbRFrr_J9QaeE7Su3fV6_ALHwN"
WATSONX_URL="https://us-south.ml.cloud.ibm.com"

print("initiate chatmodel")
chatmodel = ChatWatsonx(
    model_id='openai/gpt-oss-120b',
    project_id="fffff424-954f-4d89-883b-d48bcf921d0d",
    url="https://us-south.ml.cloud.ibm.com",
    apikey="3gzJyVBlsom4znh1OJRbRFrr_J9QaeE7Su3fV6_ALHwN",
    streaming=True,
)
print("model invoked 01")
test = chatmodel.invoke("tell me a joke")
print("model invoked")
print(test.content)